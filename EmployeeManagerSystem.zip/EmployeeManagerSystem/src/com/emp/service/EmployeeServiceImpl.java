package com.emp.service;

import java.util.List;

import com.emp.bin.EmployeeBean;
import com.emp.dao.EmployeeDao;
import com.emp.dao.EmployeeDaoImpl;
import com.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService
{
	private EmployeeDao employeedao = new EmployeeDaoImpl();

	@Override
	public int addEmp(EmployeeBean bean) throws EmployeeException 
	{
		int id= employeedao.addEmp(bean);
		return id;
	}

	@Override
	public int deleteEmp(int deleteId) throws EmployeeException 
	{
		int id = employeedao.deleteEmp(deleteId);
		return id;
	}

	@Override
	public List<EmployeeBean> viewAllEmp() throws EmployeeException 
	{
		EmployeeDaoImpl employeeDao = new EmployeeDaoImpl();
		List<EmployeeBean> employeeList = null;

		employeeList = employeeDao.viewAllEmp();
		return employeeList;
	}

	@Override
	public  EmployeeBean viewEmpById(int viewId) throws EmployeeException 
	{
		EmployeeBean bean = new EmployeeBean();
		bean = employeedao.viewEmpById(viewId);
		return bean;
	}
}
