package com.emp.dao;

import java.util.List;

import com.emp.bin.EmployeeBean;
import com.emp.exception.EmployeeException;

public interface EmployeeDao 
{
	public int addEmp(EmployeeBean bean) throws EmployeeException; 
	public int deleteEmp(int deleteId) throws EmployeeException;
	public List<EmployeeBean> viewAllEmp() throws EmployeeException;
	public EmployeeBean viewEmpById(int empid) throws EmployeeException;
}
