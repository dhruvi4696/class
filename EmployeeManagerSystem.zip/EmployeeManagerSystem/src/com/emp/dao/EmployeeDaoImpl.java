package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.emp.bin.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImpl implements EmployeeDao
{
	Scanner sc = new Scanner(System.in);
	public int generateEmployeeId()
	{
		int id=0;
		Connection  con = null;
		String str= "select empid_seq.nextval from dual";
		try {
			con=DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(str);
			rs.next();
			id=rs.getInt(1);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return id;
	}
	
	@Override
	public int addEmp(EmployeeBean bean) throws EmployeeException
	{
		int id=0;
		Connection con= null;
		String cmd="insert into emp_tbl(empid,empname,empsal) values(?,?,?)";
		
		try {
			con=DBConnection.getConnection();
			 id=generateEmployeeId();
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1,id);
			ps.setString(2,bean.getEmployeeName());
			ps.setInt(3, bean.getEmployeesalary());
			
			int n=ps.executeUpdate();
			System.out.println(n);
		}
		catch (Exception e) 
		{
			throw new EmployeeException("unable to insert");
		}
		return id;
	}

	@Override
	public int deleteEmp(int deleteId) throws EmployeeException 
	{
		Connection con= null;
		Statement stmt =null;
		
		
		try {
			con=DBConnection.getConnection();
			String cmd="delete from emp_tbl where empid ="+ deleteId;
			 stmt =con.createStatement();
			
			 ResultSet result =stmt.executeQuery(cmd);
		}
		catch (Exception e) 
		{
			throw new EmployeeException("unable to delete");
		}
		return deleteId;
	}

	@Override
	public List<EmployeeBean> viewAllEmp() throws EmployeeException
	{
		Connection con= null;
		Statement stmt =null;
		
		List<EmployeeBean> employeeList = new ArrayList<EmployeeBean>();
		try {
			con = DBConnection.getConnection();
			stmt = con.createStatement();
			String cmd = "select empid, empname, empsal from emp_tbl";
			PreparedStatement ps = null;
			ResultSet resultset = null;

			ps = con.prepareStatement(cmd);
			resultset = ps.executeQuery();

			while (resultset.next()) {
				EmployeeBean bean1 = new EmployeeBean();
				bean1.setEmployeeId(resultset.getInt(1));
				bean1.setEmployeeName(resultset.getString(2));
				bean1.setEmployeesalary(resultset.getInt(3));
				
				employeeList.add(bean1);

			}
		} catch (SQLException e) {
			System.out.println(e);

		}
		return employeeList;

	}

	@Override
	public EmployeeBean viewEmpById(int viewId) throws EmployeeException
	{
		Connection con= null;
		Statement stmt =null;
		EmployeeBean bean= new EmployeeBean();
		
		try {
			con=DBConnection.getConnection();
			String cmd="select empid,empname,empsal from emp_tbl where empid ="+ viewId;
			 stmt =con.createStatement();
			
			 ResultSet result =stmt.executeQuery(cmd);
			 if(result.next())
				{
				 bean.setEmployeeId(result.getInt(1));
					bean.setEmployeeName(result.getString(2));
					bean.setEmployeesalary(result.getInt(3));
				}
		}
		catch (Exception e) 
		{
			throw new EmployeeException("unable to view by id");
		}
		return bean;	
	}
}
