package com.emp.pl;

import java.util.List;
import java.util.Scanner;

import com.emp.bin.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.service.EmployeeService;
import com.emp.service.EmployeeServiceImpl;

public class EMSApp 
{
	public static void main(String[] args) 
	{
		System.out.println("1.add employee details");
		System.out.println("2.delete employee detail by id");
		System.out.println("3.view all employee details");
		System.out.println("4.view employee detail by id");

		Scanner sc = new Scanner (System.in);
		int choice = sc.nextInt();
		
		switch(choice)
		{
		case 1:
			System.out.println("enter employee name: ");
			String name = sc.next();
			System.out.println("enter employee salary: ");
			int salary = sc.nextInt();
			
			EmployeeBean bean = new EmployeeBean();
			bean.setEmployeeName(name);
			bean.setEmployeesalary(salary);
			EmployeeService service = new EmployeeServiceImpl();
			
			try {
				int n = service.addEmp(bean);
				System.out.println("employee added! id = "+n);
			} 
			catch (EmployeeException e) 
			{	
				e.printStackTrace();
			}
			break;
		
		case 2:
			System.out.println("enter id you want to delete : ");
			int deleteId = sc.nextInt();
			EmployeeService service1 = new EmployeeServiceImpl();
			
			try {
				int id =service1.deleteEmp(deleteId);
				System.out.println("employee deleted! id = "+id);
			}
			catch (EmployeeException e) 
			{
				e.printStackTrace();
			}
			break;
			
		case 3:
			System.out.println("enter id you want to delete : ");
			int viewId = sc.nextInt();
			EmployeeService service2 = new EmployeeServiceImpl();
			
			try {
				EmployeeBean bean1  =service2.viewEmpById(viewId);
				System.out.println("the details of id : "+viewId);
				System.out.println(bean1.toString());//getEmployeeId()+" "+bean1.getEmployeeName()+" "+bean1.getEmployeesalary());
			}
			catch (EmployeeException e) 
			{
				e.printStackTrace();
			}
			break;
			
		case 4:
			EmployeeService service3 = new EmployeeServiceImpl();
			try {
				List<EmployeeBean> list=service3.viewAllEmp();
				System.out.println("the details of all employees: ");
				 for(EmployeeBean bean1 : list)
				 {
					 System.out.println(bean1.getEmployeeId()+" "+bean1.getEmployeeName()+" "+bean1.getEmployeesalary());
				 }				
			}
			catch (EmployeeException e) 
			{
				e.printStackTrace();
			}
			break;
			
		default:
			System.out.println("enter valid choice!");
		}
	}
}
